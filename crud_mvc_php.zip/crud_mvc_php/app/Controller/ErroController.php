<?php

	class ErroController
	{
		public function index()
		{
			echo 'Página de erro';
		}
	}